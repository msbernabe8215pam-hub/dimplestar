-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2025 at 06:54 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `about`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int(11) NOT NULL,
  `history` text DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `mission` text DEFAULT NULL,
  `vision` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `history`, `image_path`, `mission`, `vision`) VALUES
(1, 'test', 'images/icon.ico', 'wawa', 'wawa');

-- --------------------------------------------------------

--
-- Table structure for table `edit_history`
--

CREATE TABLE `edit_history` (
  `id` int(11) NOT NULL,
  `about_id` int(11) NOT NULL,
  `field_name` varchar(50) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `edited_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `edit_history`
--

INSERT INTO `edit_history` (`id`, `about_id`, `field_name`, `old_value`, `new_value`, `edited_at`) VALUES
(1, 1, 'history', 'jed', 'test', '2025-09-05 04:19:14'),
(2, 1, 'history', 'test', 'test2', '2025-09-05 04:19:51'),
(3, 1, 'mission', 'To provide superior transport service to Metro Manila and Mindoro Province commuters.', 'test2', '2025-09-05 04:19:51'),
(4, 1, 'vision', 'To lead the bus transport industry through its innovation service to the riding public.', 'test2.', '2025-09-05 04:19:51'),
(5, 1, 'image_path', 'images/oldbus.jpg', 'images/icon.ico', '2025-09-05 04:19:51'),
(6, 1, 'history', 'test2', 'wawa', '2025-09-05 04:27:23'),
(7, 1, 'mission', 'test2', 'wawa', '2025-09-05 04:27:23'),
(8, 1, 'vision', 'test2.', 'wawa', '2025-09-05 04:27:23'),
(9, 1, 'history', 'wawa', 'hwllo world', '2025-09-05 04:36:42'),
(10, 1, 'image_path', 'images/icon.ico', 'images/wifi.png', '2025-09-05 04:36:42'),
(11, 1, 'history', 'hwllo world', 'test', '2025-09-05 04:42:58'),
(12, 1, 'image_path', 'images/wifi.png', 'images/icon.ico', '2025-09-05 04:42:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `edit_history`
--
ALTER TABLE `edit_history`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `edit_history`
--
ALTER TABLE `edit_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
