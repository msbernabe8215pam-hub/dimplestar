<?php
$conn = new mysqli("localhost", "root", "", "about");
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM edit_history ORDER BY edited_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit History</title>
    <style>
        body { font-family: Arial; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: #333; color: #fff; }
        tr:nth-child(even) { background: #f9f9f9; }
    </style>
</head>
<body>
    <h2>Edit History</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>About ID</th>
            <th>Field</th>
            <th>Old Value</th>
            <th>New Value</th>
            <th>Edited At</th>
        </tr>
        <?php while($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['about_id']; ?></td>
            <td><?php echo $row['field_name']; ?></td>
            <td><?php echo nl2br(htmlspecialchars($row['old_value'])); ?></td>
            <td><?php echo nl2br(htmlspecialchars($row['new_value'])); ?></td>
            <td><?php echo $row['edited_at']; ?></td>
        </tr>
        <?php } ?>
    </table>
    <a href="edit_form.php" class="btn-back">⬅ Back to Edit Form</a>
</body>
</html>
