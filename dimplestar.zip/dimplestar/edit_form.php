<?php
$conn = new mysqli("localhost", "root", "", "about");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM about_us WHERE id=1");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit About Us</title>
    <style>
        .container { max-width: 800px; margin: auto; font-family: Arial; }
        label { font-weight: bold; display: block; margin-top: 10px; }
        textarea { width: 100%; }
        .btn { margin-top: 15px; padding: 10px 20px; background: green; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:hover { background: darkgreen; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit About Us</h2>
        <form action="update_about.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="1">

            <label>History:</label>
            <textarea name="history" rows="5"><?php echo $row['history']; ?></textarea>

            <label>Mission:</label>
            <textarea name="mission" rows="5"><?php echo $row['mission']; ?></textarea>

            <label>Vision:</label>
            <textarea name="vision" rows="5"><?php echo $row['vision']; ?></textarea>

            <label>Current Image:</label><br>
            <img src="<?php echo $row['image_path']; ?>" width="200"><br><br>

            <label>Change Image:</label>
            <input type="file" name="image">

            <br><br>
            <button type="submit" class="btn">Update</button>
            <a href="about.php" class="btn-back">Back</a>
        </form>
    </div>
</body>
</html>
