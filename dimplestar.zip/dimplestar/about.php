<?php
// connect to DB
$conn = new mysqli("localhost", "root", "", "about");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// get record id=1
$result = $conn->query("SELECT * FROM about_us WHERE id=1");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; }

        /* Navbar styles */
        .navbar {
            background: #333;
            overflow: hidden;
        }
        .navbar a {
            float: left;
            display: block;
            color: #fff;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        .navbar a:hover {
            background: #575757;
        }
        .navbar a.active {
            background: blue;
        }

        /* Page container */
        .container { max-width: 800px; margin: auto; padding: 20px; }
        img { max-width: 400px; height: auto; margin-bottom: 20px; }
        .btn {
            display: inline-block; padding: 10px 20px;
            background: blue; color: white;
            text-decoration: none; border-radius: 5px;
        }
        .btn:hover { background: darkblue; }
    </style>
</head>
<body>

    <!-- ✅ Navbar -->
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="about.php" class="active">About Us</a>
        <a href="terminal.php">Terminals</a>
        <a href="routeschedule.php">Routes / Schedules</a>
        <a href="contact.php">Contact</a>
        <a href="book.php">Book Now</a>
    </div>

    <!-- ✅ About Us content -->
    <div class="container">
        <h1>About Us</h1>
        <img src="<?php echo $row['image_path']; ?>" alt="About Image"><br>

        <h2>History</h2>
        <p><?php echo nl2br($row['history']); ?></p>

        <h2>Mission</h2>
        <p><?php echo nl2br($row['mission']); ?></p>

        <h2>Vision</h2>
        <p><?php echo nl2br($row['vision']); ?></p>

        <!-- Edit Button -->
        <a href="edit_form.php" class="btn">Edit</a>
        <a href="edit_history.php">Edit History</a>

    </div>

</body>
</html>
