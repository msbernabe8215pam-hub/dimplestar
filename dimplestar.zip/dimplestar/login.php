<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['login_email'] ?? '';
    $password = $_POST['login_password'] ?? '';

    // connect to DB
    $con = new mysqli("localhost", "root", "", "users_db");
    if ($con->connect_error) {
        die("Database connection failed: " . $con->connect_error);
    }

    // prepared statement to avoid SQL injection
    $stmt = $con->prepare("SELECT id, fname, lname, password, salt FROM members WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows < 1) {
        $message = "Login Failed! Email not found.";
        header("Location: signlog.php?message=" . urlencode($message));
        exit();
    }

    $row = $result->fetch_assoc();

    // hash entered password with stored salt
    $hash = hash('sha256', $row['salt'] . hash('sha256', $password));

    if ($hash !== $row['password']) {
        $message = "Login Failed! Wrong password.";
        header("Location: signlog.php?message=" . urlencode($message));
        exit();
    }

    // ✅ Success
    session_regenerate_id(true);
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['email']   = $email;
    $_SESSION['name']    = $row['fname'] . " " . $row['lname'];

    header("Location: index.php");
    exit();
} else {
    header("Location: signlog.php?message=" . urlencode("Invalid request"));
    exit();
}
?>
