<?php
$conn = new mysqli("localhost", "root", "", "about");
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

$id      = 1; // fixed row id=1
$history = $_POST['history'] ?? '';
$mission = $_POST['mission'] ?? '';
$vision  = $_POST['vision'] ?? '';

// get current data before update
$current = $conn->query("SELECT * FROM about_us WHERE id=$id")->fetch_assoc();

$image_path = null;
if (!empty($_FILES['image']['name'])) {
    $target_dir = "images/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $image_path = $target_file;
    }
}

// update database
if ($image_path) {
    $sql = "UPDATE about_us SET history=?, mission=?, vision=?, image_path=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $history, $mission, $vision, $image_path, $id);
} else {
    $sql = "UPDATE about_us SET history=?, mission=?, vision=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $history, $mission, $vision, $id);
}

if ($stmt->execute()) {
    // ✅ record changes into edit_history
    $fields = ['history' => $history, 'mission' => $mission, 'vision' => $vision];
    if ($image_path) {
        $fields['image_path'] = $image_path;
    }

    foreach ($fields as $field => $new_val) {
        $old_val = $current[$field];
        if ($old_val !== $new_val) {
            $log = $conn->prepare("INSERT INTO edit_history (about_id, field_name, old_value, new_value) VALUES (?,?,?,?)");
            $log->bind_param("isss", $id, $field, $old_val, $new_val);
            $log->execute();
            $log->close();
        }
    }

    header("Location: about.php");
    exit();
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
